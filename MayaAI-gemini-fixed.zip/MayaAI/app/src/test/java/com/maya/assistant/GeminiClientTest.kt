package com.maya.assistant

import com.maya.assistant.ai.ChatError
import com.maya.assistant.ai.ChatException
import com.maya.assistant.ai.ChatRequest
import com.maya.assistant.ai.GeminiClient
import com.maya.assistant.data.ChatMessage
import com.maya.assistant.data.Role
import org.json.JSONObject
import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertTrue
import org.junit.Assert.fail
import org.junit.Test

class GeminiClientTest {
    private fun req(image: ByteArray? = null, web: Boolean = false) = ChatRequest(
        system = "sys", history = listOf(ChatMessage(Role.USER, "hi"), ChatMessage(Role.ASSISTANT, "hello")),
        userText = "what is this", image = image, model = "m", apiKey = "k", webSearch = web,
    )

    @Test fun bodyHasSystemHistoryAndNoToolsByDefault() {
        val o = JSONObject(GeminiClient.buildBody(req()))
        assertEquals("sys", o.getJSONObject("systemInstruction").getJSONArray("parts").getJSONObject(0).getString("text"))
        val contents = o.getJSONArray("contents")
        assertEquals(3, contents.length())
        assertEquals("model", contents.getJSONObject(1).getString("role"))
        assertFalse(o.has("tools"))
        assertFalse(o.toString().contains("\"k\"")) // key goes in a header only
    }

    @Test fun bodyIncludesImageAndSearch() {
        val o = JSONObject(GeminiClient.buildBody(req(image = byteArrayOf(1, 2, 3), web = true)))
        val parts = o.getJSONArray("contents").getJSONObject(2).getJSONArray("parts")
        assertEquals("image/jpeg", parts.getJSONObject(0).getJSONObject("inlineData").getString("mimeType"))
        assertEquals("what is this", parts.getJSONObject(1).getString("text"))
        assertTrue(o.getJSONArray("tools").getJSONObject(0).has("google_search"))
    }

    @Test fun parsesTextAndSkipsThoughts() {
        val json = """{"candidates":[{"content":{"parts":[{"text":"hmm","thought":true},{"text":"Hello "},{"text":"there"}]}}]}"""
        assertEquals("Hello there", GeminiClient.parseResponse(json))
    }

    @Test fun badResponsesThrow() {
        for (bad in listOf("not json", "{}", """{"candidates":[]}""", """{"promptFeedback":{"blockReason":"SAFETY"}}""",
            """{"candidates":[{"content":{"parts":[{"text":"  "}]}}]}""")) {
            try { GeminiClient.parseResponse(bad); fail("expected failure for $bad") }
            catch (e: ChatException) { assertEquals(ChatError.BAD_RESPONSE, e.error) }
        }
    }

    @Test fun modelListKeepsOnlyChatCapableAndStripsPrefix() {
        val json = """{"models":[
          {"name":"models/gemini-2.5-flash","displayName":"Gemini 2.5 Flash","supportedGenerationMethods":["generateContent","countTokens"]},
          {"name":"models/text-embedding-004","supportedGenerationMethods":["embedContent"]},
          {"name":"models/gemini-2.5-flash-preview-tts","supportedGenerationMethods":["generateContent"]},
          {"name":"models/gemini-3-pro","supportedGenerationMethods":["generateContent"]}]}"""
        val m = GeminiClient.parseModels(json)
        assertEquals(listOf("gemini-2.5-flash", "gemini-3-pro"), m.map { it.id })
        assertEquals("Gemini 2.5 Flash", m[0].displayName)
        assertEquals("gemini-3-pro", m[1].displayName)
    }

    @Test fun normalizesModelId() {
        assertEquals("gemini-x", GeminiClient.normalizeModelId(" models/gemini-x "))
        assertEquals("gemini-x", GeminiClient.normalizeModelId("gemini-x"))
    }

    @Test fun mapsStatuses() {
        assertEquals(ChatError.UNAUTHORIZED, GeminiClient.mapStatus(400, """{"error":{"details":[{"reason":"API_KEY_INVALID"}]}}"""))
        assertEquals(ChatError.BAD_REQUEST, GeminiClient.mapStatus(400, """{"error":{"status":"INVALID_ARGUMENT"}}"""))
        assertEquals(ChatError.UNAUTHORIZED, GeminiClient.mapStatus(403))
        assertEquals(ChatError.BAD_REQUEST, GeminiClient.mapStatus(404))
        assertEquals(ChatError.RATE_LIMITED, GeminiClient.mapStatus(429))
        assertEquals(ChatError.OVERLOADED, GeminiClient.mapStatus(503))
        assertEquals(ChatError.SERVER, GeminiClient.mapStatus(500))
        assertEquals(ChatError.UNKNOWN, GeminiClient.mapStatus(302))
    }
}
