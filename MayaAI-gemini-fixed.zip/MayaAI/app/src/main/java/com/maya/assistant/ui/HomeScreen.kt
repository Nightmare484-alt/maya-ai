package com.maya.assistant.ui

import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.tween
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.layout.imePadding
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardActions
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.Send
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material.icons.filled.Person
import androidx.compose.material.icons.filled.Settings
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.scale
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.TransformOrigin
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.semantics.contentDescription
import androidx.compose.ui.semantics.semantics
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.ImeAction
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.maya.assistant.R
import com.maya.assistant.vm.Phase
import com.maya.assistant.vm.UiError
import com.maya.assistant.vm.UiState

private fun faceFor(phase: Phase): Int = when (phase) {
    Phase.IDLE -> R.drawable.maya_happy
    Phase.LISTENING -> R.drawable.maya_serious
    Phase.THINKING -> R.drawable.maya_thinking
    Phase.SPEAKING -> R.drawable.maya_talking
    Phase.ERROR -> R.drawable.maya_surprised
}

@Composable
fun HomeScreen(
    state: UiState,
    onMic: () -> Unit,
    onCamera: () -> Unit,
    onScreen: () -> Unit,
    onApps: () -> Unit,
    onSettings: () -> Unit,
    onProfile: () -> Unit,
    onSendText: (String) -> Unit,
    onDismissError: () -> Unit,
    onAppSettings: () -> Unit,
) {
    var typing by rememberSaveable { mutableStateOf(false) }

    Box(Modifier.fillMaxSize().background(Navy)) {
        Image(
            painter = painterResource(R.drawable.maya_hero),
            contentDescription = null,
            modifier = Modifier.fillMaxSize().graphicsLayer {
                scaleX = 1.45f
                scaleY = 1.45f
                transformOrigin = TransformOrigin(0.5f, 0.28f)
            },
            contentScale = ContentScale.Crop,
            alignment = Alignment.TopCenter,
        )
        // Tint the grey-blue render toward the app's navy and fade the top and bottom for legibility.
        Box(Modifier.fillMaxSize().background(Navy.copy(alpha = 0.40f)))
        Box(
            Modifier.fillMaxSize().background(
                Brush.verticalGradient(
                    0f to Navy.copy(alpha = 0.90f),
                    0.28f to Color.Transparent,
                    0.62f to Color.Transparent,
                    0.82f to Navy.copy(alpha = 0.70f),
                    1f to Navy,
                )
            )
        )

        Column(Modifier.fillMaxSize().statusBarsPadding().navigationBarsPadding().imePadding()) {
            TopBar(onProfile = onProfile, onSettings = onSettings)
            Spacer(Modifier.weight(1f))
            ReplyBubble(
                state = state,
                onKeyboard = { typing = !typing },
                onDismissError = onDismissError,
                onSettings = onSettings,
                onAppSettings = onAppSettings,
            )
            if (typing) {
                TypeRow(onSend = { text ->
                    onSendText(text)
                    typing = false
                })
            }
            Spacer(Modifier.size(14.dp))
            ControlRow(phase = state.phase, onMic = onMic, onCamera = onCamera, onScreen = onScreen, onApps = onApps, onSettings = onSettings)
            Spacer(Modifier.size(10.dp))
        }
    }
}

@Composable
private fun TopBar(onProfile: () -> Unit, onSettings: () -> Unit) {
    Row(
        Modifier.fillMaxWidth().padding(horizontal = 16.dp, vertical = 8.dp),
        verticalAlignment = Alignment.Top,
    ) {
        RoundButton(onClick = onProfile, description = "Memory", size = 44.dp) {
            Icon(Icons.Default.Person, contentDescription = null, tint = Color.White)
        }
        Column(Modifier.weight(1f), horizontalAlignment = Alignment.CenterHorizontally) {
            Image(painterResource(R.drawable.ic_logo_m), contentDescription = null, modifier = Modifier.size(56.dp))
            Row(verticalAlignment = Alignment.CenterVertically) {
                Text("Maya AI", fontSize = 30.sp, fontWeight = FontWeight.Bold, color = Color.White)
                Spacer(Modifier.width(6.dp))
                Icon(Icons.Default.CheckCircle, contentDescription = "Verified", tint = MayaCyan, modifier = Modifier.size(22.dp))
            }
            Text(
                "Your Personal Assistant\nAlways With You \uD83D\uDC99",
                fontSize = 14.sp, color = Color.White.copy(alpha = 0.85f), textAlign = TextAlign.Center,
            )
        }
        RoundButton(onClick = onSettings, description = "Settings", size = 44.dp) {
            Icon(Icons.Default.Settings, contentDescription = null, tint = Color.White)
        }
    }
}

@Composable
private fun ReplyBubble(
    state: UiState,
    onKeyboard: () -> Unit,
    onDismissError: () -> Unit,
    onSettings: () -> Unit,
    onAppSettings: () -> Unit,
) {
    val error = state.error
    val name = state.settings.userName.trim()
    val title: String?
    val body: String
    when {
        error != null -> { title = null; body = error.message() }
        state.status != null -> { title = null; body = state.status }
        state.phase == Phase.LISTENING -> { title = null; body = state.partial.ifBlank { "Listening…" } }
        state.phase == Phase.THINKING -> { title = null; body = "Thinking…" }
        state.reply.isNotBlank() -> { title = null; body = state.reply }
        else -> {
            title = if (name.isEmpty()) "Hello!" else "Hello $name!"
            body = "I'm Maya, your AI assistant.\nHow can I help you today?"
        }
    }

    Surface(
        modifier = Modifier.padding(horizontal = 16.dp).fillMaxWidth().heightIn(max = 240.dp),
        shape = RoundedCornerShape(22.dp),
        color = CardBg,
        border = BorderStroke(1.dp, MayaBlue.copy(alpha = 0.6f)),
    ) {
        Row(Modifier.padding(14.dp), verticalAlignment = Alignment.Top) {
            Image(
                painter = painterResource(faceFor(state.phase)),
                contentDescription = "Maya, ${state.phase.name.lowercase()}",
                modifier = Modifier.size(48.dp).clip(CircleShape).border(1.5.dp, MayaCyan, CircleShape),
                contentScale = ContentScale.Crop,
            )
            Spacer(Modifier.width(12.dp))
            Column(Modifier.weight(1f).verticalScroll(rememberScrollState())) {
                if (title != null) Text(title, fontSize = 18.sp, fontWeight = FontWeight.SemiBold, color = Color.White)
                Text(
                    body,
                    fontSize = 15.sp,
                    color = if (error != null) Color(0xFFFFB4AB) else Color.White.copy(alpha = 0.92f),
                )
                if (error != null) {
                    Row {
                        when (error) {
                            UiError.MISSING_KEY, UiError.UNAUTHORIZED, UiError.BAD_REQUEST ->
                                TextButton(onClick = onSettings) { Text("Open Settings") }
                            UiError.MIC_BLOCKED -> TextButton(onClick = onAppSettings) { Text("App settings") }
                            else -> Unit
                        }
                        TextButton(onClick = onDismissError) { Text("Dismiss") }
                    }
                }
            }
            Box(
                Modifier.size(40.dp).clip(CircleShape).clickable(onClick = onKeyboard)
                    .semantics { contentDescription = "Type instead" },
                contentAlignment = Alignment.Center,
            ) {
                Icon(painterResource(R.drawable.ic_keyboard), contentDescription = null, tint = MayaCyan)
            }
        }
    }
}

@Composable
private fun TypeRow(onSend: (String) -> Unit) {
    var text by rememberSaveable { mutableStateOf("") }
    fun send() {
        if (text.isNotBlank()) {
            onSend(text)
            text = ""
        }
    }
    Row(
        Modifier.padding(horizontal = 16.dp, vertical = 8.dp).fillMaxWidth(),
        verticalAlignment = Alignment.CenterVertically,
    ) {
        OutlinedTextField(
            value = text,
            onValueChange = { text = it },
            modifier = Modifier.weight(1f),
            placeholder = { Text("Type to Maya") },
            keyboardOptions = KeyboardOptions(imeAction = ImeAction.Send),
            keyboardActions = KeyboardActions(onSend = { send() }),
            maxLines = 3,
            shape = RoundedCornerShape(20.dp),
        )
        Spacer(Modifier.width(8.dp))
        RoundButton(onClick = { send() }, description = "Send", size = 48.dp) {
            Icon(Icons.AutoMirrored.Filled.Send, contentDescription = null, tint = Color.White)
        }
    }
}

@Composable
private fun ControlRow(
    phase: Phase,
    onMic: () -> Unit,
    onCamera: () -> Unit,
    onScreen: () -> Unit,
    onApps: () -> Unit,
    onSettings: () -> Unit,
) {
    Row(
        Modifier.fillMaxWidth().padding(horizontal = 10.dp),
        horizontalArrangement = Arrangement.SpaceBetween,
        verticalAlignment = Alignment.Bottom,
    ) {
        LabeledButton("Camera", onCamera) { Icon(painterResource(R.drawable.ic_camera), null, tint = Color.White) }
        LabeledButton("Screen", onScreen) { Icon(painterResource(R.drawable.ic_screen), null, tint = Color.White) }
        MicButton(phase, onMic)
        LabeledButton("Apps", onApps) { Icon(painterResource(R.drawable.ic_apps), null, tint = Color.White) }
        LabeledButton("Settings", onSettings) { Icon(Icons.Default.Settings, null, tint = Color.White) }
    }
}

@Composable
private fun LabeledButton(label: String, onClick: () -> Unit, icon: @Composable () -> Unit) {
    Column(horizontalAlignment = Alignment.CenterHorizontally, modifier = Modifier.width(64.dp)) {
        RoundButton(onClick = onClick, description = label, size = 54.dp, content = icon)
        Spacer(Modifier.size(4.dp))
        Text(label, fontSize = 12.sp, color = Color.White)
    }
}

@Composable
private fun MicButton(phase: Phase, onClick: () -> Unit) {
    val pulse = rememberInfiniteTransition(label = "pulse")
    val factor by pulse.animateFloat(
        initialValue = 1f,
        targetValue = 1.10f,
        animationSpec = infiniteRepeatable(tween(700), RepeatMode.Reverse),
        label = "pulseScale",
    )
    val listening = phase == Phase.LISTENING
    val label = when (phase) {
        Phase.LISTENING -> "Listening… tap to send"
        Phase.THINKING -> "Thinking…"
        Phase.SPEAKING -> "Tap to stop"
        else -> "Tap to Talk"
    }
    Column(horizontalAlignment = Alignment.CenterHorizontally, modifier = Modifier.width(120.dp)) {
        Box(
            Modifier
                .size(88.dp)
                .scale(if (listening) factor else 1f)
                .clip(CircleShape)
                .background(Brush.sweepGradient(listOf(MayaBlue, MayaViolet, MayaCyan, MayaBlue)))
                .padding(3.dp)
                .clip(CircleShape)
                .background(Navy)
                .clickable(onClick = onClick)
                .semantics { contentDescription = label },
            contentAlignment = Alignment.Center,
        ) {
            val icon = if (phase == Phase.SPEAKING) R.drawable.ic_stop else R.drawable.ic_mic
            Icon(painterResource(icon), contentDescription = null, tint = MayaCyan, modifier = Modifier.size(38.dp))
        }
        Spacer(Modifier.size(4.dp))
        Text(label, fontSize = 12.sp, color = Color.White, textAlign = TextAlign.Center)
    }
}

@Composable
fun RoundButton(onClick: () -> Unit, description: String, size: Dp, content: @Composable () -> Unit) {
    Box(
        Modifier
            .size(size)
            .clip(CircleShape)
            .background(CardBg)
            .border(1.dp, MayaBlue.copy(alpha = 0.7f), CircleShape)
            .clickable(onClick = onClick)
            .semantics { contentDescription = description },
        contentAlignment = Alignment.Center,
    ) { content() }
}
