package com.maya.assistant.data

enum class Role { USER, ASSISTANT }

data class ChatMessage(val role: Role, val text: String)

data class MemoryNote(val id: Long, val text: String, val createdAt: Long)

data class MayaSettings(
    val userName: String = "Abdul Hadi",
    val model: String = DEFAULT_MODEL,
    val webSearch: Boolean = false,
    val speakReplies: Boolean = true,
) {
    companion object {
        const val DEFAULT_MODEL = "gemini-flash-latest"
    }
}
