package com.maya.assistant.voice

import android.content.Context
import android.speech.tts.TextToSpeech
import android.speech.tts.UtteranceProgressListener
import android.os.Handler
import android.os.Looper

interface Speaker {
    /** Speaks [text]; [onDone] is called when finished, stopped, or if speech is unavailable. */
    fun speak(text: String, onDone: () -> Unit)
    fun stop()
    fun release()
}

/** Removes markdown noise so replies sound natural when read aloud. */
fun stripMarkdown(text: String): String = text
    .replace(Regex("```[\\s\\S]*?```"), " code block omitted. ")
    .replace(Regex("[*_`#>~]+"), "")
    .replace(Regex("\\[(.*?)]\\((.*?)\\)"), "$1")
    .replace(Regex("\\s+"), " ")
    .trim()

class AndroidSpeaker(context: Context) : Speaker {
    private val main = Handler(Looper.getMainLooper())
    private var ready = false
    private var failed = false
    private var pending: Pair<String, () -> Unit>? = null
    private var currentDone: (() -> Unit)? = null

    private val tts: TextToSpeech = TextToSpeech(context.applicationContext) { status ->
        main.post {
            if (status == TextToSpeech.SUCCESS) {
                ready = true
                pending?.let { (t, d) -> speakNow(t, d) }
            } else {
                failed = true
                pending?.second?.invoke()
            }
            pending = null
        }
    }

    init {
        tts.setOnUtteranceProgressListener(object : UtteranceProgressListener() {
            override fun onStart(utteranceId: String?) {}
            override fun onDone(utteranceId: String?) { finish() }
            @Deprecated("Deprecated in Java")
            override fun onError(utteranceId: String?) { finish() }
            override fun onStop(utteranceId: String?, interrupted: Boolean) { finish() }
        })
    }

    private fun finish() {
        main.post {
            val d = currentDone
            currentDone = null
            d?.invoke()
        }
    }

    override fun speak(text: String, onDone: () -> Unit) {
        when {
            failed || text.isBlank() -> onDone()
            !ready -> pending = text to onDone
            else -> speakNow(text, onDone)
        }
    }

    private fun speakNow(text: String, onDone: () -> Unit) {
        currentDone = onDone
        // TTS limits a single utterance to ~4000 chars.
        val result = tts.speak(text.take(TextToSpeech.getMaxSpeechInputLength() - 1), TextToSpeech.QUEUE_FLUSH, null, "maya")
        if (result != TextToSpeech.SUCCESS) finish()
    }

    override fun stop() {
        pending = null
        if (ready) tts.stop()
    }

    override fun release() {
        tts.stop()
        tts.shutdown()
    }
}
